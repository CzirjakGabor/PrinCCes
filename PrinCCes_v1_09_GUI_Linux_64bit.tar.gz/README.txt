//There may be some requirements for proper operation on Linux.
//I have attempted to list them for two different distributions.
//Hopefully the users of other distros can also get over the difficulties...
----------------------------------------------------------------------------------------------------------------

****** Ubuntu ******

//PrinCCes requires font types (such as Tahoma, Times New Roman and Arial) for display.

//To obtain Microsoft TrueType Fonts type:

sudo apt-get install msttcorefonts
//(You have to accept EULA. Use TAB to select OK and Yes.)

//Navigate to PrinCCes directory, and issue the following commands from there: 

//Because msttcorefonts does not contain Tahoma font, please, copy tahoma.ttf from PrinCCes library by writing:

sudo cp tahoma.ttf /usr/share/fonts/truetype/msttcorefont

//Make PrinCCes binary executable:

sudo chmod +x PrinCCes

//Grant general read and write permission to PrinCCes directory:

sudo chmod -R uga+rw .
//(Don't forget the point at the end, with a space before it.)

//Run PrinCCes

./PrinCCes

//After associating PrinCCes to VMD, you may be prompted:
//'Press OK to ignore and risk data corruption.' You may risk it.

//You may also add PrinCCes directory to the path. Other system-dependent configuration is your choice as usual in Linux.
----------------------------------------------------------------------------------------------------------------

****** OpenSuse ******

//PrinCCes requires font types (such as Tahoma, Times New Roman and Arial) for display.

//To obtain Microsoft TrueType Fonts type:

sudo zypper install fetchmsttfonts
//(You have to accept EULA.)

//Navigate to PrinCCes directory, and issue the following commands from there: 

//Because msttfonts does not contain Tahoma font, please, copy tahoma.ttf from PrinCCes library by writing:

sudo cp tahoma.ttf /usr/share/fonts/truetype

//Make PrinCCes binary executable:

sudo chmod +x PrinCCes

//Grant general read and write permission to PrinCCes directory:

sudo chmod -R uga+rw .
//(Don't forget the point at the end, with a space before it.)

//Run PrinCCes

./PrinCCes

//After associating PrinCCes to VMD, you may be prompted:
//'Press OK to ignore and risk data corruption.' You may risk it.

//You may also add PrinCCes directory to the path. Other system-dependent configuration is your choice as usual in Linux.




