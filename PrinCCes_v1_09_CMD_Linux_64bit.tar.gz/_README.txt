PrinCCes v1.09 command line version for Linux.

Extract file to an empty directory.

Run "princ -h" in that directory from the command line to access help.

If further help is required or you analyze only a small number of protein structures 
then install the graphic user interface (GUI) version of PrinCCes. It includes about 
10 pages of help as green clickable texts.

The command line version can be used in batch operations and scripts.
It can also be freely integrated to your program, provided that you represent the original 
citation information in the new program at a location visually as apparent as in the 
original GUI version of PrinCCes (see _LICENCE.txt).

For theoretical background about the operation, please read the PrinCCes paper:
Czirjak, G.: PrinCCes: continuity-based geometric decomposition and systematic visualization 
of the void repertoire of proteins, J Mol Graph Model, 2015, 62:118-127.

PrinCCes command line version was compiled with Lazarus 1.4.0 using FPC 2.6.4. 
The source code is also available in the extracted directory.

Some useful commands in the PrinCCes directory:
sudo chmod +x princ
sudo chmod -R uga+rw .
./princ -h




